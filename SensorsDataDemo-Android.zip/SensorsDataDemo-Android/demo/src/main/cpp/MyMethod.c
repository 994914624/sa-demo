//
// Created by yang on 2017/9/5.
//

#include "MyMethod.h"


#include <jni.h>

