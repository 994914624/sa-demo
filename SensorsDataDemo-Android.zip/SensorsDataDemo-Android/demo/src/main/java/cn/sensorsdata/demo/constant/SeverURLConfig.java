package cn.sensorsdata.demo.constant;

/**
 * Created by yang on 2017/11/8.
 */

public class SeverURLConfig {

    //我的数据接收地址
    public final static String SA_MY = "http://test2-zouyuhan.cloud.sensorsdata.cn:8006/sa?project=yangzhankun&token=386e4bed00b5701e";
    //分析师
    public final static String SA_ANALYST = "http://saasdemo.cloud.sensorsdata.cn:8006/sa?project=default&token=102672f0642fd2e9";
}
