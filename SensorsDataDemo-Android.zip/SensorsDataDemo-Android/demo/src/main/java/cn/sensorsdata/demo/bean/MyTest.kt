package cn.sensorsdata.demo.bean

/**
 * Created by yang on 2017/6/2.
 */

class MyTest {
    private val name: String? = null

}

