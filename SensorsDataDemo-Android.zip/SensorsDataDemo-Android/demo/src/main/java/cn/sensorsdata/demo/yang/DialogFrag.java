package cn.sensorsdata.demo.yang;

import android.content.Context;
import android.support.v4.app.DialogFragment;

/**
 * Created by yang on 2018/3/2.
 */

public class DialogFrag extends DialogFragment {
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }
}
