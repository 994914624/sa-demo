package cn.test.lib;

import java.util.LinkedHashMap;
import java.util.Map;

public class APT {

    private static final Map<Class<?>, AptActivityListener<Object>> linkedHashMap = new LinkedHashMap<Class<?>, AptActivityListener<Object>>();

    /**
     * bind
     */
    public static void bind(Object activity){
        AptActivityListener instance=newInstance(activity);
        if(instance!=null) {
            instance.inject(activity);
        }
    }

    /**
     *  AptActivityListener 的实例
     */
    private static AptActivityListener<Object> newInstance(Object activity){
        Class<?> clazz = activity.getClass();
        AptActivityListener<Object> instance = linkedHashMap.get(clazz);
        if (instance == null) {
            try {
                Class generateClazz = Class.forName(clazz.getName() + "_New");
                instance = (AptActivityListener<Object>) generateClazz.newInstance();
                linkedHashMap.put(clazz, instance);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return instance;
    }

    /**
     * unbind
     */
    public static void unbind(Object activity){
        Class<?> clazz = activity.getClass();
        linkedHashMap.remove(clazz);
    }
}
