package cn.test.lib;

public interface AptActivityListener<T> {
    void inject(T target);
}
