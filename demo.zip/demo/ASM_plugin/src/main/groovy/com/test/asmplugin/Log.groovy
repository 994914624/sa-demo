package com.test.asmplugin

class Log {
    static void d(String message) {
        println("------------- " + message)
    }
}