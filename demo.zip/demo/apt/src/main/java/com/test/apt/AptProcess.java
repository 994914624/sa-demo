package com.test.apt;

import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.TypeName;
import com.squareup.javapoet.TypeSpec;
import cn.test.lib.TargetActivity;

import java.io.IOException;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.Filer;
import javax.annotation.processing.Messager;
import javax.annotation.processing.ProcessingEnvironment;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.TypeElement;
import javax.lang.model.util.Elements;
import javax.lang.model.element.Element;



public class AptProcess extends AbstractProcessor {

    private Elements elementUtils;
    private Messager messager;
    Filer filer;
    @Override
    public synchronized void init(ProcessingEnvironment processingEnvironment) {
        super.init(processingEnvironment);
        elementUtils = processingEnvironment.getElementUtils();
        messager = processingEnvironment.getMessager();
        filer=processingEnvironment.getFiler();
    }

    @Override
    public SourceVersion getSupportedSourceVersion() {
        return SourceVersion.RELEASE_7;
    }

    @Override
    public Set<String> getSupportedAnnotationTypes() {
        Set<String> annotationTypes = new LinkedHashSet<>();
        annotationTypes.add(TargetActivity.class.getCanonicalName());
        annotationTypes.add(TargetActivity.Click.class.getCanonicalName());
        return annotationTypes;
    }

    @Override
    public boolean process(Set<? extends TypeElement> set, RoundEnvironment roundEnvironment) {
        Set<? extends Element> elements = roundEnvironment.getElementsAnnotatedWith(TargetActivity.class);
        //遍历 @TargetActivity
        for (Element element : elements) {
            TypeElement typeElement = (TypeElement) element;
            List<? extends Element> members = elementUtils.getAllMembers(typeElement);

            // targetField
            FieldSpec.Builder targetField = FieldSpec.builder(TypeName.get(element.asType()), "mTarget", Modifier.PRIVATE);

            // injectMethod
            MethodSpec.Builder injectMethod =MethodSpec.methodBuilder("inject")
                    .addModifiers(Modifier.PUBLIC)
                    .addParameter(Object.class,"target")
                    .addStatement("mTarget=(MainActivity)target")
                    .addAnnotation(Override.class)
                    .returns(TypeName.VOID);

            //遍历 @Click
            for (Element item : members) {
                TargetActivity.Click testClick = item.getAnnotation(TargetActivity.Click.class);
                if (testClick == null){
                    continue;
                }
                ExecutableElement executableElement = (ExecutableElement) item;

                // onClick
                MethodSpec.Builder onClick = MethodSpec.methodBuilder("onClick")
                        .addModifiers(Modifier.PUBLIC)
                        .returns(TypeName.VOID)
                        .addParameter(ClassName.get("android.view","View"), "view")
                        .addAnnotation(Override.class)
                        .addStatement("mTarget.$N()",executableElement.getSimpleName())
                        ;

                injectMethod.beginControlFlow("mTarget.findViewById($L).setOnClickListener(new $T.OnClickListener()",testClick.value(),ClassName.get("android.view","View"))
                        .addCode(onClick.build().toString())
                        .endControlFlow(")");
            }

            // class
            TypeSpec typeSpec = TypeSpec.classBuilder(element.getSimpleName()+"_New")
                    .addModifiers(Modifier.PUBLIC, Modifier.FINAL)
                    .addJavadoc(" this java create by APT \n")
                    .addSuperinterface(ClassName.get("cn.test.lib","AptActivityListener"))
                    .addField(targetField.build())
                    .addMethod(injectMethod.build())
                    .build();
            JavaFile javaFile = JavaFile.builder(getPackageName(typeElement), typeSpec).build();
            try {
                javaFile.writeTo(filer);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return true;
    }

    private String getPackageName(TypeElement type) {
        return elementUtils.getPackageOf(type).getQualifiedName().toString();
    }
}
