package com.test.apt;


import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.sun.source.tree.Tree;
import com.sun.source.tree.TreeVisitor;
import com.sun.source.util.Trees;
import com.sun.tools.javac.code.Flags;
import com.sun.tools.javac.processing.JavacProcessingEnvironment;
import com.sun.tools.javac.tree.JCTree;
import com.sun.tools.javac.tree.TreeMaker;
import com.sun.tools.javac.tree.TreeTranslator;
import com.sun.tools.javac.util.Context;
import com.sun.tools.javac.util.List;
import com.sun.tools.javac.util.Name;
import com.sun.tools.javac.util.Names;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Set;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.Messager;
import javax.annotation.processing.ProcessingEnvironment;
import javax.annotation.processing.Processor;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedAnnotationTypes;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.TypeElement;
import javax.tools.Diagnostic;



//@AutoService(Processor.class)
@SupportedSourceVersion(SourceVersion.RELEASE_7)
@SupportedAnnotationTypes("*")
public class AstProcess extends AbstractProcessor {

    private int tally;
    private Trees trees;
    private TreeMaker make;
    private Name.Table names;
    private Messager messager;

    @Override
    public synchronized void init(ProcessingEnvironment env) {
        super.init(env);
        messager = env.getMessager();
        trees = Trees.instance(env);
        Context context = ((JavacProcessingEnvironment)
                env).getContext();
        make = TreeMaker.instance(context);
        names = Names.instance(context).table;//Name.Table.instance(context);
        tally = 0;
    }

    @Override
    public boolean process(Set<? extends TypeElement> set, RoundEnvironment roundEnv) {
        if (set == null || set.isEmpty()) {
            return false;
        }

        if (!roundEnv.processingOver()) {
            Set<? extends Element> elements = roundEnv.getRootElements();
            for (Element each : elements) {
                if (each.getKind() == ElementKind.CLASS) {
                    JCTree tree = (JCTree) trees.getTree(each);
                    TreeTranslator visitor2 = new LogClear();
                    tree.accept(visitor2);

                }


            }
        }
        return true;

//        FileInputStream in = null;
//        try {
//            in = new FileInputStream(new File("/Users/yang/Desktop/demo/apt/src/main/java/com/test/apt/AstProcess.java"
//            ));
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }
//
//        // parse it
//        CompilationUnit cu = JavaParser.parse(in);
//
//        // visit and print the methods names
//        cu.accept(new MyVisitor(), null);
//        return true;
    }




    /**
     * 操作 Log.
     */
    private class LogClear extends TreeTranslator {
        @Override
        public void visitBlock(JCTree.JCBlock jcBlock) {
            super.visitBlock(jcBlock);
            final List<JCTree.JCStatement> statements = jcBlock.getStatements();
            if (statements != null && statements.size() > 0) {
                List<JCTree.JCStatement> out = List.nil();
                for (JCTree.JCStatement statement : statements) {
                    if (statement.toString().startsWith("Log.")) {
                        messager.printMessage(Diagnostic.Kind.WARNING, this.getClass().getCanonicalName() + "_________Log###_________" + statement.toString());

                        //copy statement 一次
                        out=out.append(statement)
                                .append(statement);
                    } else {
                        out = out.append(statement);
                    }
                }
                jcBlock.stats = out;
            }
        }
    }
}