package cn.test.lib;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * TargetActivity
 */
@Retention(RetentionPolicy.CLASS)
@Target({ElementType.TYPE})
public @interface TargetActivity {


    /**
     * Click
     */
    @Retention(RetentionPolicy.CLASS)
    @Target({ElementType.METHOD})
    @interface Click {
        int value();
    }
}
