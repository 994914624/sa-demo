package com.test.demo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.sensorsdata.analytics.android.sdk.ScreenAutoTracker;
import com.sensorsdata.analytics.android.sdk.SensorsDataAPI;

import org.json.JSONException;
import org.json.JSONObject;

public class BaseActivity extends AppCompatActivity implements ScreenAutoTracker {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base);
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            SensorsDataAPI.sharedInstance().trackTimerEnd("AppViewScreen",new JSONObject().put("page_id",""+this.getClass().getCanonicalName()));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        //SensorsDataAPI.sharedInstance().login("555_"+ new Random().nextInt(100));
        SensorsDataAPI.sharedInstance().trackTimerBegin("AppViewScreen");
    }

    @Override
    public String getScreenUrl() {
        return null;
    }

    @Override
    public JSONObject getTrackProperties() throws JSONException {
        return null;
    }
}
