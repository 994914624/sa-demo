package com.test.demo.fragment;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sensorsdata.analytics.android.sdk.SensorsDataTrackFragmentAppViewScreen;
import com.test.demo.R;

/**
 * A simple {@link Fragment} subclass.
 */
@SensorsDataTrackFragmentAppViewScreen
public class BaseFragment extends Fragment {

    private static final String TAG="SA.Sensors.BaseFragment";
    public BaseFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.e(TAG,"onCreateView: "+this.getClass().getCanonicalName());
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_base, container, false);
    }

    @Override
    public void onResume() {
        Log.e(TAG,"onResume: "+this.getClass().getCanonicalName()+"，VisibleHint: "+getUserVisibleHint()+"，Hidden: "+isHidden()+"，Resume: "+isResumed());
        super.onResume();

    }

    @Override
    public void onPause() {
        Log.e(TAG,"onPause: "+this.getClass().getCanonicalName()+"，VisibleHint: "+getUserVisibleHint()+"，Hidden: "+isHidden()+"，Resume: "+isResumed());
        super.onPause();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        Log.e(TAG,"setUserVisibleHint: "+this.getClass().getCanonicalName()+"，VisibleHint: "+isVisibleToUser+"，Hidden: "+isHidden()+"，Resume: "+isResumed());
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        Log.e(TAG,"onHiddenChanged "+this.getClass().getCanonicalName()+"，VisibleHint: "+getUserVisibleHint()+"，Hidden: "+hidden+"，Resume: "+isResumed());
        super.onHiddenChanged(hidden);
    }

    @Override
    public void setMenuVisibility(boolean menuVisible) {
        Log.e(TAG,"setMenuVisibility "+this.getClass().getCanonicalName()+"，VisibleHint: "+getUserVisibleHint()+"，Hidden: "+isHidden()+"，Resume: "+isResumed()+"，menuVisible："+menuVisible);
        super.setMenuVisibility(menuVisible);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
