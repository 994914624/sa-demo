package com.test.demo;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;

import com.sensorsdata.analytics.android.sdk.SensorsDataAPI;
import com.test.demo.fragment.Frg_1;
import com.test.demo.fragment.Frg_2;
import com.test.demo.fragment.Frg_3;

import java.util.ArrayList;
import java.util.List;

public class ViewPgerActivity extends BaseActivity {
    private static final String TAG="SA.Sensors.ViewPger111";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_pger);
        initViewPager();
    }



    private List<Fragment> listPagerViews = null;
    private PagerAdapter pagerAdapter=null;
    private void initViewPager() {
        listPagerViews=new ArrayList<>();

        listPagerViews.add(new Frg_1());
        listPagerViews.add(new Frg_2());
        listPagerViews.add(new Frg_3());
        ViewPager viewPager= (ViewPager) findViewById(R.id.view_pager_activity_vp);
        pagerAdapter=new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public android.support.v4.app.Fragment getItem(int position) {
                return listPagerViews.get(position);
            }

            @Override
            public int getCount() {
                return listPagerViews.size();
            }

            @Override
            public void setPrimaryItem(ViewGroup container, int position, Object object) {
                super.setPrimaryItem(container, position, object);
               // Log.e(TAG,"setPrimaryItem: "+object.getClass().getCanonicalName()+"position:"+position);
            }

        };

        viewPager.setAdapter(pagerAdapter);

    }


}
