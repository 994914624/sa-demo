package com.button.test;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import butterknife.internal.Utils;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Unbinder unbinder = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        unbinder = ButterKnife.bind(this);
        type1();
        type2();
        type3();
        type6();
        type8();
    }




    /**
     * 1.匿名内部类方式。
     */
    private void type1() {
        findViewById(R.id.main_button_1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "按钮1", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * 2.实现 View.OnClickListener 接口重写 onClick 方式。
     */
    private void type2() {
        findViewById(R.id.main_button_2).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Toast.makeText(MainActivity.this, "按钮2", Toast.LENGTH_SHORT).show();
    }


    /**
     * 3. View.OnClickListener 的实现类方式。
     */
    private void type3() {
        findViewById(R.id.main_button_3).setOnClickListener(new ButtonListener());
    }

    public class ButtonListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            Toast.makeText(MainActivity.this, "按钮3", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * 4. XML 中 OnClick 方式。
     * 属性名字对应为方法名
     */
    public void type4(View v) {
        Toast.makeText(MainActivity.this, "按钮4", Toast.LENGTH_SHORT).show();
    }


    /**
     * 5.ButterKnife 方式。
     * 通过反射拿到 view 设置 setOnClickListener
     */

//    public MainActivity_ViewBinding(final MainActivity target, View source) {
//        this.target = target;
//        View view = Utils.findRequiredView(source, R.id.main_button_5, "method 'butterKnife'");
//        this.view2131165243 = view;
//        view.setOnClickListener(new DebouncingOnClickListener() {
//            public void doClick(View p0) {
//                target.butterKnife(p0);
//            }
//        });
//    }
    @OnClick(R.id.main_button_5)
    public void butterKnife(View v) {
        Toast.makeText(MainActivity.this, "按钮5", Toast.LENGTH_SHORT).show();
    }


    /**
     * 6.setOnTouchListener 或 重新 onTouchEvent 方式。
     *
     */
    private void type6() {
        findViewById(R.id.main_button_6).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        Toast.makeText(MainActivity.this, "按钮6", Toast.LENGTH_SHORT).show();
                    default:
                        break;
                }
                return true;
            }
        });
//        findViewById(R.id.main_button_6).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(MainActivity.this, "按钮66", Toast.LENGTH_SHORT).show();
//            }
//        });
        findViewById(R.id.main_button_6).performClick();
    }


    /**
     * dispatchTouchEvent --> OnTouchListener --> onTouchEvent --> performClick --> OnClickListener
     */
    private void type8() {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbinder.unbind();

        //View view = Utils.findRequiredView(source, R.id.main_button_5, "method 'butterKnife'");
    }

}

