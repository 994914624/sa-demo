package com.button.test;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.Toast;

/**
 * Created by yang on 2018/3/17
 */

public class CustomButton2 extends android.support.v7.widget.AppCompatButton{
    public CustomButton2(Context context) {
        super(context);
    }

    public CustomButton2(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CustomButton2(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    /**
     * 8. 自定义View performClick 方式。
     *
     * Call this view's OnClickListener, if it is defined.  Performs all normal
     * actions associated with clicking: reporting accessibility event, playing
     * a sound, etc.
     */
    @Override
    public boolean performClick() {
        Toast.makeText(getContext(),"按钮8",Toast.LENGTH_SHORT).show();
        return super.performClick();
    }


}
