package com.sensorsdata.analytics.android.sdk.java_websocket.exceptions;

public class WebsocketNotConnectedException extends RuntimeException {

}
